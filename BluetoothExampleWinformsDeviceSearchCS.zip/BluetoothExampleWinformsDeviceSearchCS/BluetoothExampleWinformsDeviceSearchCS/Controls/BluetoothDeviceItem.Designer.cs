﻿namespace BluetoothExampleWinformsDeviceSearchCS.Controls;

partial class BluetoothDeviceItem
{
    /// <summary> 
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Vom Komponenten-Designer generierter Code

    /// <summary> 
    /// Erforderliche Methode für die Designerunterstützung. 
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
            this.lblDeviceName = new System.Windows.Forms.Label();
            this.lblBluetoothAddress = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDeviceName
            // 
            this.lblDeviceName.AutoEllipsis = true;
            this.lblDeviceName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDeviceName.Location = new System.Drawing.Point(53, 18);
            this.lblDeviceName.Name = "lblDeviceName";
            this.lblDeviceName.Size = new System.Drawing.Size(162, 23);
            this.lblDeviceName.TabIndex = 0;
            this.lblDeviceName.Text = "DeviceName";
            // 
            // lblBluetoothAddress
            // 
            this.lblBluetoothAddress.Location = new System.Drawing.Point(53, 51);
            this.lblBluetoothAddress.Name = "lblBluetoothAddress";
            this.lblBluetoothAddress.Size = new System.Drawing.Size(162, 15);
            this.lblBluetoothAddress.TabIndex = 1;
            this.lblBluetoothAddress.Text = "Address";
            // 
            // BluetoothDeviceItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.lblBluetoothAddress);
            this.Controls.Add(this.lblDeviceName);
            this.Name = "BluetoothDeviceItem";
            this.Size = new System.Drawing.Size(236, 82);
            this.ResumeLayout(false);

    }

    #endregion

    private Label lblDeviceName;
    private Label lblBluetoothAddress;
}
