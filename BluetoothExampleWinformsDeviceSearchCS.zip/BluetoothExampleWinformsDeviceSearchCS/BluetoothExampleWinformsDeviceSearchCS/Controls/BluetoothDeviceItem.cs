﻿using InTheHand.Net.Sockets;

namespace BluetoothExampleWinformsDeviceSearchCS.Controls;

public partial class BluetoothDeviceItem : UserControl
{

    public BluetoothDeviceInfo Device { get; set; }

    public BluetoothDeviceItem(BluetoothDeviceInfo bluetoothDeviceInfo)
    {
        Device = bluetoothDeviceInfo;
        InitializeComponent();

        lblDeviceName.Text = Device.DeviceName;
        lblBluetoothAddress.Text = Device.DeviceAddress.ToString();
    }
}
