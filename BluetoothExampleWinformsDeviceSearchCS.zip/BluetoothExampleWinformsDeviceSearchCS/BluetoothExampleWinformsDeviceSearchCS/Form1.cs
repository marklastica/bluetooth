using BluetoothExampleWinformsDeviceSearchCS.Controls;
using InTheHand.Net.Sockets;

namespace BluetoothExampleWinformsDeviceSearchCS;

public partial class Form1 : Form
{
    List<BluetoothDeviceInfo> _bluetoothDevices;

    bool _isSearchingForDevices;

    public bool IsSearchingForDevices
    {
        get => _isSearchingForDevices;
        set
        {
            _isSearchingForDevices = value;
            btnScanForDevices.Enabled = !_isSearchingForDevices;
        }
    }

    public Form1()
    {
        InitializeComponent();
        _bluetoothDevices = new List<BluetoothDeviceInfo>();
        lbBluetoothDevices.DisplayMember = "DeviceName";
    }

    private async void btnScanForDevices_Click(object sender, EventArgs e)
    {
        IsSearchingForDevices = true;
        _bluetoothDevices.Clear();
        flpBluetoothDevices.Controls.Clear();
        lbBluetoothDevices.Items.Clear();
        BluetoothDeviceInfo[]? bluetoothDevices;
        try
        {
            bluetoothDevices = await SearchDevicesAsync();
            _bluetoothDevices.AddRange(bluetoothDevices);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Couldn't search for bluetooth devices: {ex.Message}");
        }
        if (_bluetoothDevices.Count > 0)
        {
            DisplayFlpItems();
            DisplayLbItems();
        }
        IsSearchingForDevices = false;
    }

    private void DisplayFlpItems()
    {
        foreach (var device in _bluetoothDevices)
        {
            var bluetoothDeviceItem = new BluetoothDeviceItem(device);
            bluetoothDeviceItem.Click += BluetoothDeviceItem_Click;
            flpBluetoothDevices.Controls.Add(bluetoothDeviceItem);
        }
    }

    private void BluetoothDeviceItem_Click(object? sender, EventArgs e)
    {
        var deviceItem = sender as BluetoothDeviceItem;
        var device = deviceItem!.Device;
        MessageBox.Show($"You clicked on device: {device!.DeviceName}");
    }

    private void DisplayLbItems()
    {
        lbBluetoothDevices.DataSource = _bluetoothDevices;
    }

    public async Task<BluetoothDeviceInfo[]> SearchDevicesAsync()
    {
        var bluetoothClient = new BluetoothClient();
        var bluetoothDevices = await Task.Run(() => bluetoothClient.DiscoverDevices());
        bluetoothClient.Close();
        return bluetoothDevices;
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (flpBluetoothDevices.Controls.Count > 0)
        {
            foreach (var bluetoothDeviceItem in flpBluetoothDevices.Controls.OfType<BluetoothDeviceItem>())
            {
                bluetoothDeviceItem.Click -= BluetoothDeviceItem_Click;
            }
        }
    }
}
