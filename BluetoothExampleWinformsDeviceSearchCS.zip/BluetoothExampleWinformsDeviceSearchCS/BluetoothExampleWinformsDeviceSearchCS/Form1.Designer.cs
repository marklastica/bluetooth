﻿namespace BluetoothExampleWinformsDeviceSearchCS;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.flpBluetoothDevices = new System.Windows.Forms.FlowLayoutPanel();
            this.btnScanForDevices = new System.Windows.Forms.Button();
            this.lblBluetoothDevices = new System.Windows.Forms.Label();
            this.lbBluetoothDevices = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // flpBluetoothDevices
            // 
            this.flpBluetoothDevices.AutoScroll = true;
            this.flpBluetoothDevices.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpBluetoothDevices.Location = new System.Drawing.Point(12, 37);
            this.flpBluetoothDevices.Name = "flpBluetoothDevices";
            this.flpBluetoothDevices.Size = new System.Drawing.Size(289, 241);
            this.flpBluetoothDevices.TabIndex = 0;
            // 
            // btnScanForDevices
            // 
            this.btnScanForDevices.Location = new System.Drawing.Point(166, 300);
            this.btnScanForDevices.Name = "btnScanForDevices";
            this.btnScanForDevices.Size = new System.Drawing.Size(191, 52);
            this.btnScanForDevices.TabIndex = 1;
            this.btnScanForDevices.Text = "Scan for Bluetooth devices";
            this.btnScanForDevices.UseVisualStyleBackColor = true;
            this.btnScanForDevices.Click += new System.EventHandler(this.btnScanForDevices_Click);
            // 
            // lblBluetoothDevices
            // 
            this.lblBluetoothDevices.AutoSize = true;
            this.lblBluetoothDevices.Location = new System.Drawing.Point(12, 19);
            this.lblBluetoothDevices.Name = "lblBluetoothDevices";
            this.lblBluetoothDevices.Size = new System.Drawing.Size(101, 15);
            this.lblBluetoothDevices.TabIndex = 2;
            this.lblBluetoothDevices.Text = "Bluetooth devices";
            // 
            // lbBluetoothDevices
            // 
            this.lbBluetoothDevices.FormattingEnabled = true;
            this.lbBluetoothDevices.ItemHeight = 15;
            this.lbBluetoothDevices.Location = new System.Drawing.Point(307, 37);
            this.lbBluetoothDevices.Name = "lbBluetoothDevices";
            this.lbBluetoothDevices.Size = new System.Drawing.Size(179, 244);
            this.lbBluetoothDevices.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 364);
            this.Controls.Add(this.lbBluetoothDevices);
            this.Controls.Add(this.lblBluetoothDevices);
            this.Controls.Add(this.btnScanForDevices);
            this.Controls.Add(this.flpBluetoothDevices);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    private FlowLayoutPanel flpBluetoothDevices;
    private Button btnScanForDevices;
    private Label lblBluetoothDevices;
    private ListBox lbBluetoothDevices;
}
